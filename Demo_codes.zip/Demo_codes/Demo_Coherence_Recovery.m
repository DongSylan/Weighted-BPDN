%% Initializing the enviroment
   close all
   clear all
   clc
   rng('default')
   
   
%% Load the toolbox of functions for MC
    PATH_Functions = genpath('Functions_WBPDN');
    addpath(PATH_Functions);
   
   
%% Public parameters
    m = 64;                  % Sample times
    n = 256;                 % The length of signal
    s = 16;                   %  The block-sparsity of signals
  % Parameters to control the partially known support information
    rho = 1;
    alpha = 0.5;
  % Noise level
    sigma = 0.02;
  % Parameters for saprse signals
    Opt_x.Dis = 'randn';
  % Parameters for measurement matrix
    Opt_Phi.Dis = 'randn';
   

%% Parameters for algorithm
    lambda = 1e-2;
    Options.nu = 1e2;
    Options.MAX_ITER = 1000;
    Options.ERROR_BOUND = 1e-6;
    
   
%% Main
 % Generate the sparse signal and the measurement matrix
   [A_randn, x_Original, Support_Prior] = A_and_x(m, n, s, Opt_x, Opt_Phi, rho, alpha);
 % Generate the desired measurement matrix with low coherence
   %%%------------ It will run for a long time ------------%%%
   A = DesignGrass(m, n, 10000, 0.90, 0.90, A_randn);
   %%%------------ It will run for a long time ------------%%%
 % compute coherence
   fprintf(['Coherence of A is ' num2str(coherence(A)) '\n']);
 % Generate the observed signal 
   b_Noise_free = A*x_Original;
   Noise = sigma*randn(m, 1);
   norm(Noise)
   b = b_Noise_free + Noise;
 % Recovered via Weighted BPDN
   omega = 0.5;
   Options.x_Original = x_Original;
   tic
   [x_sharp, Error_RNIE, Error_RTIE] = Weighted_BPDN(A, b, Support_Prior, omega, lambda, Options);
   t= toc
   SNR = -20*log10(norm(x_sharp - x_Original, 2)/norm(x_Original, 2))
   
   
%% Figure
    figure
    h1 = stem(x_Original);
    set(h1, 'Color', 'm', 'LineStyle', '--', 'LineWidth', 2, 'Marker', '*', 'MarkerSize', 10)
    hold on
    h2 = stem(x_sharp);
    set(h2, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 10)
    h1h2_legend = legend([h1, h2], 'Original signal', 'Recovered signal',  'Location', [0.57, 0.15, 0.15, 0.15]); % [left, bottom, width, heigh]=[0.2, 0.2, 0.15, 0.15] );
    xlabel('Location', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('Value', 'FontWeight', 'bold', 'FontSize', 20);
    set(h1h2_legend, 'FontWeight', 'bold', 'FontSize', 20); % [left, bottom, width, heigh]=[0.2, 0.2, 0.15, 0.15]
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on
    
    figure
    h1 = plot(log10(Error_RNIE));
    set(h1, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2)
    xlabel('i-th iteration', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0RNIE(i)', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on
   
    figure
    h2 = plot(log10(Error_RTIE));
    set(h2, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2)
    xlabel('i-th iteration', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0RTIE(i)', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on  
    
  
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   
 