function [A, x, Support_Prior] = A_and_x(m, n, s, Opt_x, Opt_A, rho, alpha)

% Generate the proper measurement matrix A, s-sparse signal x and its Location                                                                                      
%           m: sample time
%           n: length of signal x
%           s: block sparsity

%       Opt_x: It includes following terms
%   Opt_x.Dis: pm for the distribute of the block-sparse signal('randn','rand','01')
% Opt_x.Spike: pm for the type of block-sparse signal('Yes', 'No')
%    Opt_x.RL: pm for the Rayleigh length(RL) of block-sparse signal (integer)

%     Opt_A: It includes following terms
% Opt_A.Dis: pm for the distribute of the measurement matrix('randn','rand','hada-mard',)
%   Opt_A.F: The refinement factor of randomly oversampled partial DCT


%%%----Generate the sparse signal x

  if ~isfield(Opt_x,'Spike')
      Opt_x.Spike = 'No';
  end 
  x  = zeros(n, 1);
  switch Opt_x.Dis
      case  'randn'
          if strcmp(Opt_x.Spike, 'Yes')
              Support = randsample_separated(n, s, Opt_x.RL);
              x(Support) = randn(length(Support), 1);
          else
              Support = randperm(n, s);
              x(Support) = randn(length(Support), 1);
          end
      case  'rand'
          if strcmp(Opt_x.Spike, 'Yes')
              Support = randsample_separated(n, s, Opt_x.RL);
              x(Support) = rand(length(Support), 1);
          else
              Support = randperm(n, s);
              x(Support) = rand(length(Support), 1);
          end
      case  '01'
          if strcmp(Opt_x.Spike, 'Yes')
              Support = randsample_separated(n, s, Opt_x.RL);
              x(Support) = 1;
          else
              Support = randperm(n, s);
              x(Support) = 1;
          end
      otherwise
          disp('Wrong parameters are provided. Please check your input related to ''Opt_x'' carefully.')     
  end
  
%%%----Generate the support_prior of x according to x, rho and alpha
  
% random selection of Ture Prior Support (TPS)
  num_TPS = round(alpha*rho*s);  
  TPS = Support(randperm(s, num_TPS));
% random selection of Wrong Prior Support (WPS)
  Non_Support = setdiff(1:n, Support);
  num_WPS = round(rho*s - alpha*rho*s);   
  WPS = Non_Support(randperm(n-s, num_WPS));
  Support_Prior = union(TPS, WPS);
  
%%%----Generate the measurement matrix A

  switch Opt_A.Dis
      case  'randn'
          A = randn(m, n);
      case  'rand'
          A = rand(m, n); 
      case   'Gauss'
          A = normrnd(0,1/sqrt(m), m, n);
      case   'P_DCT'
          A = zeros(m, n);
          r = rand(m, 1);
          for i = 1:n 
              A(:, i) = cos(2*(i-1)*pi*r)/sqrt(m);
          end
      otherwise
          disp('Wrong parameters are provided. Please check your input related to ''Opt_A'' carefully.')          
  end    
end


